package Interview;

import java.util.*;

public class SumOfDigit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Read the integer n (not used in calculations but can be used for input validation)
        int n = sc.nextInt();
        // Read the string s
        String s = sc.next();
        
        // Convert string to a character array and sort in descending order
        char[] arr = s.toCharArray();
        Arrays.sort(arr);
        // Reverse the array to get descending order
        for (int i = 0; i < arr.length / 2; i++) {
            char temp = arr[i];
            arr[i] = arr[arr.length - 1 - i];
            arr[arr.length - 1 - i] = temp;
        }

        // Initialize sums
        int sum = 0;
        int sum1 = 0;

        // Calculate the total sum of digits
        for (char c : arr) {
            sum += (c - '0'); // Convert char to int and add to sum
        }

        // Calculate the maximum sum until sum1 exceeds half of total sum
        for (char c : arr) {
            if (sum1 > sum) break; // Break if sum1 exceeds the remaining sum
            sum1 += (c - '0'); // Add to sum1
            sum -= (c - '0'); // Reduce the sum
        }

        // Output the result
        System.out.println(sum1);
        
        sc.close(); // Close the scanner
    }
}
