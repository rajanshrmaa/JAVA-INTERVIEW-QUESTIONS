package Interview;

import java.util.Scanner;

public class GuessTheWord {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Read the number of strings
        int n = scanner.nextInt();
        scanner.nextLine();  // Consume the newline character after the integer input
        
        // Read the strings
        String[] words = scanner.nextLine().split(" ");
        
        // Variable to keep track of the longest odd-length word
        String longestOddWord = null;
        
        // Process each word
        for (String word : words) {
            int length = word.length();  // Get the length of the word
            
            // Check if the length is odd
            if (length % 2 != 0) {
                // If it's the first odd-length word found or it's longer than the current longest
                if (longestOddWord == null || length > longestOddWord.length()) {
                    longestOddWord = word;
                }
            }
        }
        
        // Output the result
        if (longestOddWord != null) {
            System.out.println(longestOddWord);
        } else {
            System.out.println("Better luck next time");
        }
    }
}
