package Interview;

import java.util.HashMap;
import java.util.Scanner;

public class FolderNameSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Read the number of folder requests
        int n = scanner.nextInt();
        scanner.nextLine();  // Consume the newline character

        String[] folderNames = new String[n];

        // Read folder names
        for (int i = 0; i < n; i++) {
            folderNames[i] = scanner.nextLine();
        }

        // Process folder names to make them unique
        String[] uniqueFolderNames = createUniqueFolderNames(folderNames);

        // Output the unique folder names
        for (String name : uniqueFolderNames) {
            System.out.println(name);
        }

        scanner.close();
    }

    public static String[] createUniqueFolderNames(String[] folderNames) {
        HashMap<String, Integer> folderCountMap = new HashMap<>();
        String[] result = new String[folderNames.length];

        for (int i = 0; i < folderNames.length; i++) {
            String folderName = folderNames[i];

            // Check if the folder name already exists
            if (folderCountMap.containsKey(folderName)) {
                // Get the current count for this folder name
                int count = folderCountMap.get(folderName);
                // Generate a new unique folder name
                String newFolderName = folderName + count;
                // Increment the count for the next potential duplicate
                folderCountMap.put(folderName, count + 1);

                // Check if the new folder name already exists
                while (folderCountMap.containsKey(newFolderName)) {
                    newFolderName = folderName + count;
                    count++;
                }

                result[i] = newFolderName;
                folderCountMap.put(newFolderName, 1); // Add new folder name to the map
            } else {
                // If the folder name is unique, add it directly
                result[i] = folderName;
                folderCountMap.put(folderName, 1); // Mark it as existing
            }
        }

        return result;
    }
}
