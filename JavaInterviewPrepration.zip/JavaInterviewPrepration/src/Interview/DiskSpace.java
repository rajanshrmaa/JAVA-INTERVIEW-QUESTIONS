package Interview;

import java.util.*;

class DiskSpace {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Read the length of the subarray and the size of the array
        int x = sc.nextInt();
        int n = sc.nextInt();
        int arr[] = new int[n];
        
        // Read the elements of the array
        for (int i = 0; i < n; i++)
            arr[i] = sc.nextInt();

        int max = Integer.MIN_VALUE; // To store the maximum of the minimums

        // Loop through each possible starting point for the subarray
        for (int i = 0; i <= n - x; i++) {
            int min = Integer.MAX_VALUE; // Reset min for the new subarray
            
            // Find the minimum in the current subarray
            for (int j = i; j < i + x; j++) {
                min = Math.min(min, arr[j]);
            }
            
            // Update max if the current minimum is larger
            max = Math.max(min, max);
        }
        
        // Print the result
        System.out.println(max);
    }
}
