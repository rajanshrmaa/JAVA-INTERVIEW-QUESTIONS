package Interview;

import java.util.Scanner;

class MinimumOccurence {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Read the input string
        String str = sc.next();
        char[] arr = str.toCharArray();
        
        // Array to store frequency of ASCII characters
        int[] temp = new int[256];
        
        // Count the frequency of each character
        for (char c : arr) {
            temp[c]++;
        }
        
        int min = Integer.MAX_VALUE; // Initialize minimum frequency
        // Loop to find the minimum frequency
        for (int count : temp) {
            if (count > 0) {
                min = Math.min(min, count);
            }
        }
        
        // Loop to find the first character with the minimum frequency
        for (char c : arr) {
            if (temp[c] == min) {
                System.out.println(c); // Output the result
                break; // Exit after finding the first occurrence
            }
        }
        
        sc.close(); // Close the scanner
    }
}
