package Interview;

import java.util.Scanner;

public class TrapeziumPattern {
    public static void main(String[] args) {
        // Create a Scanner object to read user input
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number n : ");
        // Read the size of the trapezium pattern
        int n = sc.nextInt();
        int i, j;

        // First part of the trapezium pattern
        for (i = 0; i < n; i++) {
            // Print the left part of the trapezium
            for (j = 0; j < n; j++) {
                // Print '*' for the decreasing left side
                if (j < n - i - 1) {
                    System.out.print("*");
                } else {
                    System.out.print("."); // Print '.' for the right side
                }
            }
            // Print the right part of the trapezium
            for (j = 0; j < n - 1; j++) {
                // Print '.' for the increasing left side
                if (j < i) {
                    System.out.print(".");
                } else {
                    System.out.print("*"); // Print '*' for the right end
                }
            }
            System.out.println(); // Move to the next line after finishing the row
        }

        // Second part of the trapezium pattern
        for (i = 2; i <= n; i++) {
            // Print the left part of the trapezium
            for (j = 0; j < n; j++) {
                // Print '*' for the increasing left side
                if (j < i - 1) {
                    System.out.print("*");
                } else {
                    System.out.print("."); // Print '.' for the right side
                }
            }
            // Print the right part of the trapezium
            for (j = 0; j < n - 1; j++) {
                // Print '.' for the decreasing left side
                if (j < n - i) {
                    System.out.print(".");
                } else {
                    System.out.print("*"); // Print '*' for the right end
                }
            }
            System.out.println(); // Move to the next line after finishing the row
        }
        
        sc.close(); // Close the scanner to free resources
    }
}
