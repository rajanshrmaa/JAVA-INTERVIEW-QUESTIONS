package Interview;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class Duplicates {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Read the number of integers
        int n = scanner.nextInt();
        
        // Use a HashMap to count occurrences
        HashMap<Integer, Integer> countMap = new HashMap<>();
        
        // Read the integers and count their occurrences
        for (int i = 0; i < n; i++) {
            int number = scanner.nextInt();
            countMap.put(number, countMap.getOrDefault(number, 0) + 1);
        }
        
        // Use a HashSet to store duplicates
        HashSet<Integer> duplicates = new HashSet<>();
        
        // Find duplicates
        for (int key : countMap.keySet()) {
            if (countMap.get(key) > 1) {
                duplicates.add(key);
            }
        }
        
        // Output the duplicates
        if (duplicates.isEmpty()) {
            System.out.println("No duplicates");
        } else {
            for (int dup : duplicates) {
                System.out.print(dup + " ");
            }
            System.out.println(); // For a new line after the duplicates
        }

        scanner.close();
    }
}
