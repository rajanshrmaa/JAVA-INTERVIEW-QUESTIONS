package Interview;

import java.util.Scanner;

public class AdjustArraySum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Read the size of the array
        int n = sc.nextInt();
        int[] a = new int[n];

        // Read the elements of the array
        for (int i = 0; i < n; i++) {
            a[i] = sc.nextInt();
        }

        int sum = 0; // To keep track of the cumulative sum
        int ans = 0; // To store the total adjustments needed

        // Iterate through the array to calculate adjustments
        for (int i = 0; i < n; i++) {
            sum += a[i]; // Update the cumulative sum

            // Check if the cumulative sum is less than 1
            if (sum < 1) {
                ans += (1 - sum); // Calculate the adjustment needed
                sum = 1; // Reset sum to 1
            }
        }

        // Output the total adjustments needed
        System.out.println(ans);
        
        sc.close(); // Close the scanner
    }
}
