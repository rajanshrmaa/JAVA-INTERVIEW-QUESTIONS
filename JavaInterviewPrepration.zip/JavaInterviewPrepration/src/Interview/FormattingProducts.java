package Interview;

import java.util.Scanner;

public class FormattingProducts {
    public static String formatProducts(int a, int b) {
        long result = 1; // Use long to handle larger products
        for (int i = a; i <= b; i++) {
            result *= i;
        }

        int power = 0; // To count trailing zeros
        while (result % 10 == 0) {
            power++;
            result /= 10; // Remove trailing zeros
        }
        
        return result + " * 10^" + power; // Return formatted string
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.println(formatProducts(a, b));
        sc.close();
    }
}
