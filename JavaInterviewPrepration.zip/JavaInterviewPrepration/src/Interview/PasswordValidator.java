package Interview;

import java.util.Scanner;

public class PasswordValidator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        
        if (isValidPassword(password)) {
            System.out.println("password valid");
        } else {
            System.out.println("Invalid password, try again");
        }
        
        scanner.close();
    }
    
    public static boolean isValidPassword(String password) {
        // Check length
        if (password.length() < 6) {
            return false;
        }
        
        // Check for disallowed characters
        if (password.contains(" ") || password.contains("/")) {
            return false;
        }

        // Check for at least one lowercase letter
        boolean hasLower = false;
        // Check for at least one uppercase letter
        boolean hasUpper = false;
        // Check for at least one digit
        boolean hasDigit = false;

        for (char ch : password.toCharArray()) {
            if (Character.isLowerCase(ch)) {
                hasLower = true;
            } else if (Character.isUpperCase(ch)) {
                hasUpper = true;
            } else if (Character.isDigit(ch)) {
                hasDigit = true;
            }
        }

        return hasLower && hasUpper && hasDigit;
    }
}
