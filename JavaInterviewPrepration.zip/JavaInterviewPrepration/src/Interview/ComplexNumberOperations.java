package Interview;

import java.util.Scanner;

public class ComplexNumberOperations {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Read three integers a, b, and c
        int a = sc.nextInt(); // Real part
        int b = sc.nextInt(); // Imaginary part
        int c = sc.nextInt(); // Additional integer

        // Print the complex number in the format a + bi
        System.out.println(a + " + " + b + "i");

        // Calculate and print a + bi + c as a new complex number
        int realPart2 = a + c; // Real part
        int imagPart2 = b;     // Imaginary part
        System.out.println(realPart2 + " + " + imagPart2 + "i");

        // Calculate and print (i2 + a + bi)
        int realPart3 = realPart2 + a; // Real part
        int imagPart3 = imagPart2 + b; // Imaginary part
        System.out.println(realPart3 + " + " + imagPart3 + "i");

        sc.close(); // Close the scanner
    }
}
