package Interview;

import java.util.Scanner;

public class Lines {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Read input string
        System.out.print("Enter the text: ");
        String input = scanner.nextLine();
        
        // Split the input string into words
        String[] words = input.trim().split("\\s+");
        
        // Calculate the number of words
        int numberOfWords = words.length;
        
        // Calculate the number of lines (divide the number of words by 2)
        int numberOfLines = (int) Math.ceil(numberOfWords / 2.0);
        
        // Output the result
        System.out.println(numberOfLines);
        
        scanner.close();
    }
}
