package Interview;

import java.util.Scanner;

public class TotalSetBits {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Read the number of integers
        int n = scanner.nextInt();
        int totalSetBits = 0;

        // Iterate through the next n lines to read the integers
        for (int i = 0; i < n; i++) {
            int number = scanner.nextInt();
            totalSetBits += countSetBits(number);
        }
        
        // Output the total number of set bits
        System.out.println(totalSetBits);
        
        scanner.close();
    }
    
    // Method to count set bits in an integer
    public static int countSetBits(int number) {
        int count = 0;
        while (number > 0) {
            count += (number & 1); // Increment count if the last bit is set
            number >>= 1;          // Right shift the number by 1
        }
        return count;
    }
}
